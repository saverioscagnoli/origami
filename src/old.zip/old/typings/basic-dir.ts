import { ReactNode } from "react";

type BasicDir = {
  path: string;
  icon: ReactNode;
};

export type { BasicDir };
